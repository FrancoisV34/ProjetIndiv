# LevelUp - Habit Tracker Gamifie

Habit tracker gamifie inspire de Habitica. Stack MEAN (MongoDB + Express + Angular 19 + Node.js).

---

## Prerequis logiciels (macOS)

Ces outils doivent etre installes sur le Mac avant de commencer :

| Outil | Version minimum | Verification | Installation |
|-------|----------------|--------------|--------------|
| **Node.js** | 18+ (recommande 20+) | `node -v` | `brew install node` ou https://nodejs.org/ |
| **npm** | 9+ (inclus avec Node) | `npm -v` | Inclus avec Node.js |
| **Docker Desktop** | 4+ | `docker -v` | https://www.docker.com/products/docker-desktop/ |
| **Git** | 2+ | `git -v` | `brew install git` (ou inclus avec Xcode CLT) |

### Installer Homebrew (si pas deja fait)

```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

### Installer Node.js et Git via Homebrew

```bash
brew install node git
```

### Installer Docker Desktop

Telecharger depuis https://www.docker.com/products/docker-desktop/ et installer le .dmg.

> **Important :** Apres installation, lancer Docker Desktop et attendre que l'icone baleine dans la barre de menu soit stable (pas en animation). Docker doit tourner en arriere-plan pour que les commandes `docker` fonctionnent.

---

## Installation complete (nouvel ordinateur)

### 1. Cloner ou dezipper le projet

```bash
# Si depuis un zip :
unzip Claude-habits.zip
cd Claude-habits

# Si depuis git :
git clone <url-du-repo>
cd Claude-habits
```

### 2. Lancer la base de donnees MongoDB

```bash
docker compose up -d
```

Cela telecharge l'image MongoDB 7 et lance un conteneur sur le port **27017**.

Pour verifier que ca tourne :

```bash
docker ps
# Vous devez voir un conteneur "levelup-mongo" en status "Up"
```

### 3. Installer et lancer le backend

```bash
cd backend

# Creer le fichier de configuration
cp .env.example .env

# Installer les dependances Node.js
npm install

# Lancer le serveur (port 3000)
npm run dev
```

Le backend affiche `MongoDB connected` puis `Server running on port 3000` quand c'est bon.

> **Laisser ce terminal ouvert** et en ouvrir un nouveau pour la suite.

### 4. Installer et lancer le frontend

```bash
cd frontend

# Installer les dependances (Angular + Material + etc.)
npm install

# Lancer le serveur de developpement (port 4200)
npx ng serve --proxy-config proxy.conf.json
```

La premiere compilation prend 10-20 secondes. Quand vous voyez `Compiled successfully`, c'est pret.

### 5. Ouvrir l'application

Aller sur : **http://localhost:4200**

1. Creer un compte (page Inscription)
2. Se connecter
3. Creer des habitudes
4. Les completer pour gagner de l'XP et monter de niveau

---

## Arreter le projet

```bash
# Arreter le frontend : Ctrl+C dans son terminal
# Arreter le backend : Ctrl+C dans son terminal

# Arreter MongoDB
docker compose down

# Pour supprimer aussi les donnees MongoDB :
docker compose down -v
```

---

## Structure du projet

```
Claude-habits/
├── docker-compose.yml       # Conteneur MongoDB
├── backend/                 # API Express (port 3000)
│   ├── .env.example         # Variables d'environnement (a copier en .env)
│   ├── package.json         # Dependances backend
│   └── src/
│       ├── server.js        # Point d'entree
│       ├── app.js           # Config Express (routes, CORS)
│       ├── config/db.js     # Connexion MongoDB
│       ├── models/          # Schemas Mongoose (User, Habit)
│       ├── controllers/     # Logique des endpoints
│       ├── routes/          # Definition des routes
│       ├── services/        # Logique gamification (XP, streaks)
│       ├── middleware/       # Auth JWT, validation
│       ├── validators/      # Regles de validation
│       └── utils/           # Fonctions utilitaires dates
└── frontend/                # Angular 19 (port 4200)
    ├── proxy.conf.json      # Proxy /api -> backend
    ├── package.json         # Dependances frontend
    └── src/app/
        ├── core/            # Services, guards, interceptors, modeles
        ├── features/        # Pages (auth, dashboard, habits)
        └── shared/          # Composants partages (navbar, toast)
```

---

## API Endpoints

| Methode | Route | Auth | Description |
|---------|-------|------|-------------|
| POST | `/api/auth/register` | Non | Inscription (email + password) |
| POST | `/api/auth/login` | Non | Connexion, retourne un JWT |
| GET | `/api/users/me` | Oui | Profil utilisateur |
| GET | `/api/users/me/stats` | Oui | Stats (XP, level, streaks) |
| GET | `/api/habits` | Oui | Liste des habitudes |
| POST | `/api/habits` | Oui | Creer une habitude |
| PUT | `/api/habits/:id` | Oui | Modifier une habitude |
| DELETE | `/api/habits/:id` | Oui | Supprimer une habitude |
| POST | `/api/habits/:id/complete` | Oui | Completer (+10 XP, streak) |

---

## Fonctionnalites

- Inscription / Connexion (JWT)
- CRUD habitudes (quotidien / hebdomadaire)
- Systeme de streaks (serie de jours consecutifs)
- Gain d'XP (+10 par completion)
- Systeme de niveaux (level = XP / 100 + 1)
- Dashboard avec stats et barre XP animee
- Animation level-up

---

## Depannage

| Probleme | Solution |
|----------|----------|
| `MongoDB connected` n'apparait pas | Verifier que Docker Desktop tourne (icone baleine dans la barre de menu) |
| Port 3000 deja utilise | Modifier `PORT` dans `backend/.env` |
| Port 4200 deja utilise | Lancer avec `npx ng serve --port 4201 --proxy-config proxy.conf.json` |
| `ng: command not found` | Utiliser `npx ng serve` au lieu de `ng serve` |
| Erreur CORS | Verifier que le proxy.conf.json est bien passe en argument de `ng serve` |
| `npm install` echoue | Verifier la version Node avec `node -v` (doit etre 18+) |
| Mac Apple Silicon (M1/M2/M3) | Aucun probleme connu, Docker Desktop et Node supportent nativement ARM |

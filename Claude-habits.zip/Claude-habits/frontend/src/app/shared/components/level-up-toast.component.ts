import { Component, input } from '@angular/core';

@Component({
  selector: 'app-level-up-toast',
  template: `
    <div class="level-up-overlay">
      <div class="level-up-content">
        <div class="level-up-icon">&#127881;</div>
        <h2>Level Up !</h2>
        <p>Tu es maintenant niveau {{ level() }}</p>
      </div>
    </div>
  `,
  styles: [`
    .level-up-overlay {
      position: fixed;
      top: 0; left: 0; right: 0; bottom: 0;
      background: rgba(0, 0, 0, 0.6);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 9999;
      animation: fadeIn 0.3s ease;
    }
    .level-up-content {
      background: linear-gradient(135deg, #7c3aed, #a855f7);
      color: white;
      padding: 48px;
      border-radius: 24px;
      text-align: center;
      animation: scaleIn 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
    }
    .level-up-icon {
      font-size: 4rem;
      margin-bottom: 8px;
    }
    h2 {
      font-size: 2rem;
      margin: 0 0 8px;
    }
    p {
      font-size: 1.2rem;
      margin: 0;
      opacity: 0.9;
    }
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
    @keyframes scaleIn {
      from { transform: scale(0.5); opacity: 0; }
      to { transform: scale(1); opacity: 1; }
    }
  `]
})
export class LevelUpToastComponent {
  level = input.required<number>();
  visible = input.required<boolean>();
}

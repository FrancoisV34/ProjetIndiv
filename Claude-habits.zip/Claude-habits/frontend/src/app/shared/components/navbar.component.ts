import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-navbar',
  imports: [RouterLink, MatToolbarModule, MatButtonModule, MatIconModule],
  template: `
    <mat-toolbar class="navbar">
      <span class="brand" routerLink="/dashboard">LevelUp</span>
      <span class="spacer"></span>
      @if (auth.isAuthenticated()) {
        <span class="user-info">{{ auth.user()?.email }}</span>
        <button mat-button (click)="auth.logout()">
          <mat-icon>logout</mat-icon>
          Deconnexion
        </button>
      } @else {
        <a mat-button routerLink="/login">Connexion</a>
        <a mat-flat-button routerLink="/register">Inscription</a>
      }
    </mat-toolbar>
  `,
  styles: [`
    .navbar {
      background: linear-gradient(135deg, #7c3aed, #6d28d9);
      color: white;
    }
    .brand {
      font-weight: 700;
      font-size: 1.3rem;
      cursor: pointer;
      letter-spacing: -0.5px;
    }
    .spacer { flex: 1; }
    .user-info {
      margin-right: 12px;
      opacity: 0.85;
      font-size: 0.9rem;
    }
  `]
})
export class NavbarComponent {
  constructor(public auth: AuthService) {}
}

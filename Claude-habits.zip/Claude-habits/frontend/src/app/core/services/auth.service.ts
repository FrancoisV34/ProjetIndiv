import { Injectable, signal, computed } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { tap } from 'rxjs';
import { AuthResponse, User } from '../models/user.model';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private currentUser = signal<User | null>(null);

  user = this.currentUser.asReadonly();
  isAuthenticated = computed(() => !!this.currentUser());

  constructor(private http: HttpClient, private router: Router) {
    const token = localStorage.getItem('token');
    if (token) {
      this.loadUser();
    }
  }

  register(email: string, password: string) {
    return this.http.post<AuthResponse>('/api/auth/register', { email, password }).pipe(
      tap(res => this.setSession(res))
    );
  }

  login(email: string, password: string) {
    return this.http.post<AuthResponse>('/api/auth/login', { email, password }).pipe(
      tap(res => this.setSession(res))
    );
  }

  logout() {
    localStorage.removeItem('token');
    this.currentUser.set(null);
    this.router.navigate(['/login']);
  }

  getToken(): string | null {
    return localStorage.getItem('token');
  }

  updateUser(user: User) {
    this.currentUser.set(user);
  }

  private setSession(res: AuthResponse) {
    localStorage.setItem('token', res.token);
    this.currentUser.set(res.user);
  }

  private loadUser() {
    this.http.get<User>('/api/users/me').subscribe({
      next: user => this.currentUser.set(user),
      error: () => {
        localStorage.removeItem('token');
        this.currentUser.set(null);
      }
    });
  }
}

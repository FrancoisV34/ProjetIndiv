import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User, UserStats } from '../models/user.model';

@Injectable({ providedIn: 'root' })
export class UserService {
  constructor(private http: HttpClient) {}

  getMe() {
    return this.http.get<User>('/api/users/me');
  }

  getStats() {
    return this.http.get<UserStats>('/api/users/me/stats');
  }
}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Habit, CompleteResponse } from '../models/habit.model';

@Injectable({ providedIn: 'root' })
export class HabitService {
  constructor(private http: HttpClient) {}

  list() {
    return this.http.get<Habit[]>('/api/habits');
  }

  create(data: { title: string; type: 'daily' | 'weekly' }) {
    return this.http.post<Habit>('/api/habits', data);
  }

  update(id: string, data: { title: string; type: 'daily' | 'weekly' }) {
    return this.http.put<Habit>(`/api/habits/${id}`, data);
  }

  delete(id: string) {
    return this.http.delete(`/api/habits/${id}`);
  }

  complete(id: string) {
    return this.http.post<CompleteResponse>(`/api/habits/${id}/complete`, {});
  }
}

export interface User {
  _id: string;
  email: string;
  xp: number;
  level: number;
  createdAt: string;
}

export interface UserStats {
  xp: number;
  level: number;
  xpForNextLevel: number;
  xpProgress: number;
  totalHabits: number;
  completionsToday: number;
  bestStreak: number;
  currentStreak: number;
}

export interface AuthResponse {
  token: string;
  user: User;
}

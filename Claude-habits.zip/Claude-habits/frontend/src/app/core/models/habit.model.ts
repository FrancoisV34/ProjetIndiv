export interface Habit {
  _id: string;
  userId: string;
  title: string;
  type: 'daily' | 'weekly';
  completedDates: string[];
  streak: number;
  bestStreak: number;
  createdAt: string;
}

export interface CompleteResponse {
  habit: Habit;
  user: { _id: string; email: string; xp: number; level: number };
  xpGained: number;
  leveledUp: boolean;
  newLevel: number;
}

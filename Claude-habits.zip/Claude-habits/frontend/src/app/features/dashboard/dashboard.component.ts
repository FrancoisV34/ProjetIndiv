import { Component, OnInit, signal } from '@angular/core';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { HabitService } from '../../core/services/habit.service';
import { UserService } from '../../core/services/user.service';
import { AuthService } from '../../core/services/auth.service';
import { Habit } from '../../core/models/habit.model';
import { UserStats } from '../../core/models/user.model';
import { StatsCardComponent } from './stats-card.component';
import { XpBarComponent } from './xp-bar.component';
import { HabitListComponent } from '../habits/habit-list.component';
import { HabitFormComponent } from '../habits/habit-form.component';
import { LevelUpToastComponent } from '../../shared/components/level-up-toast.component';

@Component({
  selector: 'app-dashboard',
  imports: [
    MatDialogModule,
    MatSnackBarModule,
    StatsCardComponent,
    XpBarComponent,
    HabitListComponent,
    LevelUpToastComponent,
  ],
  template: `
    @if (stats()) {
      <app-xp-bar
        [xpProgress]="stats()!.xpProgress"
        [xpForNextLevel]="stats()!.xpForNextLevel"
        [level]="stats()!.level"
      />

      <div class="stats-grid">
        <app-stats-card icon="bolt" [value]="stats()!.xp" label="XP Total" color="#7c3aed" />
        <app-stats-card icon="local_fire_department" [value]="stats()!.currentStreak" label="Streak actuel" color="#f59e0b" />
        <app-stats-card icon="emoji_events" [value]="stats()!.bestStreak" label="Meilleur streak" color="#ef4444" />
        <app-stats-card icon="check_circle" [value]="stats()!.completionsToday" label="Fait aujourd'hui" color="#22c55e" />
      </div>
    }

    <app-habit-list
      [habits]="habits()"
      (onAdd)="openForm()"
      (onComplete)="completeHabit($event)"
      (onEdit)="openForm($event)"
      (onDelete)="deleteHabit($event)"
    />

    @if (showLevelUp()) {
      <app-level-up-toast [level]="newLevel()" [visible]="showLevelUp()" />
    }
  `,
  styles: [`
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 16px;
      margin-bottom: 32px;
    }
  `]
})
export class DashboardComponent implements OnInit {
  habits = signal<Habit[]>([]);
  stats = signal<UserStats | null>(null);
  showLevelUp = signal(false);
  newLevel = signal(1);

  constructor(
    private habitService: HabitService,
    private userService: UserService,
    private authService: AuthService,
    private dialog: MatDialog,
    private snackBar: MatSnackBar,
  ) {}

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.habitService.list().subscribe(habits => this.habits.set(habits));
    this.userService.getStats().subscribe(stats => this.stats.set(stats));
  }

  openForm(habit?: Habit) {
    const ref = this.dialog.open(HabitFormComponent, {
      data: habit ? { habit } : undefined,
    });

    ref.afterClosed().subscribe(result => {
      if (!result) return;
      const op = habit
        ? this.habitService.update(habit._id, result)
        : this.habitService.create(result);

      op.subscribe({
        next: () => {
          this.loadData();
          this.snackBar.open(habit ? 'Habitude modifiee' : 'Habitude creee', 'OK', { duration: 2000 });
        },
        error: () => this.snackBar.open('Erreur', 'OK', { duration: 2000 }),
      });
    });
  }

  completeHabit(id: string) {
    this.habitService.complete(id).subscribe({
      next: (res) => {
        this.authService.updateUser(res.user as any);
        this.loadData();
        this.snackBar.open(`+${res.xpGained} XP !`, 'OK', { duration: 2000 });

        if (res.leveledUp) {
          this.newLevel.set(res.newLevel);
          this.showLevelUp.set(true);
          setTimeout(() => this.showLevelUp.set(false), 3000);
        }
      },
      error: (err) => {
        this.snackBar.open(err.error?.error || 'Erreur', 'OK', { duration: 2000 });
      },
    });
  }

  deleteHabit(id: string) {
    this.habitService.delete(id).subscribe({
      next: () => {
        this.loadData();
        this.snackBar.open('Habitude supprimee', 'OK', { duration: 2000 });
      },
      error: () => this.snackBar.open('Erreur', 'OK', { duration: 2000 }),
    });
  }
}

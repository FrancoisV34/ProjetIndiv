import { Component, input, computed } from '@angular/core';
import { MatProgressBarModule } from '@angular/material/progress-bar';

@Component({
  selector: 'app-xp-bar',
  imports: [MatProgressBarModule],
  template: `
    <div class="xp-bar-container">
      <div class="xp-header">
        <span class="xp-level">Niveau {{ level() }}</span>
        <span class="xp-text">{{ xpProgress() }} / {{ xpForNextLevel() }} XP</span>
      </div>
      <mat-progress-bar
        mode="determinate"
        [value]="percentage()"
        class="xp-progress"
      />
    </div>
  `,
  styles: [`
    .xp-bar-container {
      padding: 16px 0;
    }
    .xp-header {
      display: flex;
      justify-content: space-between;
      margin-bottom: 8px;
    }
    .xp-level {
      font-weight: 700;
      font-size: 1.1rem;
      color: #7c3aed;
    }
    .xp-text {
      font-size: 0.9rem;
      opacity: 0.7;
    }
    .xp-progress {
      border-radius: 8px;
      height: 12px;
    }
    :host ::ng-deep .mdc-linear-progress__bar-inner {
      border-color: #7c3aed !important;
    }
    :host ::ng-deep .mdc-linear-progress__buffer-bar {
      background-color: #ede9fe !important;
    }
  `]
})
export class XpBarComponent {
  xpProgress = input.required<number>();
  xpForNextLevel = input.required<number>();
  level = input.required<number>();

  percentage = computed(() => {
    const max = this.xpForNextLevel();
    return max > 0 ? (this.xpProgress() / max) * 100 : 0;
  });
}

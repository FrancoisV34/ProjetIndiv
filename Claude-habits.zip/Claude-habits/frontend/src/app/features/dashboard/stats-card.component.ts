import { Component, input } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-stats-card',
  imports: [MatCardModule, MatIconModule],
  template: `
    <mat-card class="stats-card">
      <div class="stats-icon" [style.background]="color()">
        <mat-icon>{{ icon() }}</mat-icon>
      </div>
      <div class="stats-info">
        <span class="stats-value">{{ value() }}</span>
        <span class="stats-label">{{ label() }}</span>
      </div>
    </mat-card>
  `,
  styles: [`
    .stats-card {
      display: flex;
      flex-direction: row;
      align-items: center;
      padding: 16px;
      gap: 16px;
    }
    .stats-icon {
      width: 48px;
      height: 48px;
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      flex-shrink: 0;
    }
    .stats-info {
      display: flex;
      flex-direction: column;
    }
    .stats-value {
      font-size: 1.5rem;
      font-weight: 700;
      line-height: 1.2;
    }
    .stats-label {
      font-size: 0.85rem;
      opacity: 0.7;
    }
  `]
})
export class StatsCardComponent {
  icon = input.required<string>();
  value = input.required<string | number>();
  label = input.required<string>();
  color = input<string>('#7c3aed');
}

import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { Habit } from '../../core/models/habit.model';

export interface HabitFormData {
  habit?: Habit;
}

@Component({
  selector: 'app-habit-form',
  imports: [FormsModule, MatDialogModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule],
  template: `
    <h2 mat-dialog-title>{{ isEdit ? 'Modifier' : 'Nouvelle habitude' }}</h2>
    <mat-dialog-content>
      <mat-form-field appearance="outline" class="full-width">
        <mat-label>Titre</mat-label>
        <input matInput [(ngModel)]="title" maxlength="100" required />
      </mat-form-field>
      <mat-form-field appearance="outline" class="full-width">
        <mat-label>Type</mat-label>
        <mat-select [(ngModel)]="type">
          <mat-option value="daily">Quotidien</mat-option>
          <mat-option value="weekly">Hebdomadaire</mat-option>
        </mat-select>
      </mat-form-field>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button mat-dialog-close>Annuler</button>
      <button mat-flat-button color="primary" (click)="save()" [disabled]="!title.trim()">
        {{ isEdit ? 'Modifier' : 'Creer' }}
      </button>
    </mat-dialog-actions>
  `,
  styles: [`
    .full-width { width: 100%; }
    mat-dialog-content { display: flex; flex-direction: column; gap: 4px; min-width: 320px; }
  `]
})
export class HabitFormComponent {
  private dialogRef = inject(MatDialogRef<HabitFormComponent>);
  private data = inject<HabitFormData>(MAT_DIALOG_DATA, { optional: true });

  isEdit: boolean;
  title: string;
  type: 'daily' | 'weekly';

  constructor() {
    this.isEdit = !!this.data?.habit;
    this.title = this.data?.habit?.title || '';
    this.type = this.data?.habit?.type || 'daily';
  }

  save() {
    if (!this.title.trim()) return;
    this.dialogRef.close({ title: this.title.trim(), type: this.type });
  }
}

import { Component, input, output } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { Habit } from '../../core/models/habit.model';
import { HabitCardComponent } from './habit-card.component';

@Component({
  selector: 'app-habit-list',
  imports: [MatButtonModule, MatIconModule, HabitCardComponent],
  template: `
    <div class="list-header">
      <h2>Mes habitudes</h2>
      <button mat-fab extended color="primary" (click)="onAdd.emit()">
        <mat-icon>add</mat-icon>
        Nouvelle habitude
      </button>
    </div>
    @if (habits().length === 0) {
      <div class="empty-state">
        <p>Aucune habitude pour le moment.</p>
        <p>Cree ta premiere habitude pour commencer a gagner de l'XP !</p>
      </div>
    }
    @for (habit of habits(); track habit._id) {
      <app-habit-card
        [habit]="habit"
        (onComplete)="onComplete.emit($event)"
        (onEdit)="onEdit.emit($event)"
        (onDelete)="onDelete.emit($event)"
      />
    }
  `,
  styles: [`
    .list-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 16px;
    }
    .list-header h2 {
      margin: 0;
      font-size: 1.3rem;
    }
    .empty-state {
      text-align: center;
      padding: 48px 16px;
      opacity: 0.6;
    }
  `]
})
export class HabitListComponent {
  habits = input.required<Habit[]>();

  onAdd = output<void>();
  onComplete = output<string>();
  onEdit = output<Habit>();
  onDelete = output<string>();
}

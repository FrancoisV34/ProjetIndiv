import { Component, input, output } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { Habit } from '../../core/models/habit.model';

@Component({
  selector: 'app-habit-card',
  imports: [MatCardModule, MatButtonModule, MatIconModule, MatChipsModule],
  template: `
    <mat-card class="habit-card" [class.completed]="isCompletedToday()">
      <div class="habit-info">
        <div class="habit-top">
          <h3 class="habit-title">{{ habit().title }}</h3>
          <mat-chip-set>
            <mat-chip [highlighted]="habit().type === 'daily'">
              {{ habit().type === 'daily' ? 'Quotidien' : 'Hebdo' }}
            </mat-chip>
          </mat-chip-set>
        </div>
        <div class="habit-meta">
          <span class="streak">Streak: {{ habit().streak }}</span>
          <span class="best-streak">Record: {{ habit().bestStreak }}</span>
        </div>
      </div>
      <div class="habit-actions">
        @if (!isCompletedToday()) {
          <button mat-fab extended color="primary" (click)="onComplete.emit(habit()._id)">
            <mat-icon>check</mat-icon>
            +10 XP
          </button>
        } @else {
          <button mat-fab extended disabled>
            <mat-icon>done_all</mat-icon>
            Fait !
          </button>
        }
        <div class="secondary-actions">
          <button mat-icon-button (click)="onEdit.emit(habit())">
            <mat-icon>edit</mat-icon>
          </button>
          <button mat-icon-button (click)="onDelete.emit(habit()._id)">
            <mat-icon>delete</mat-icon>
          </button>
        </div>
      </div>
    </mat-card>
  `,
  styles: [`
    .habit-card {
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: space-between;
      padding: 16px 20px;
      margin-bottom: 12px;
      transition: all 0.2s ease;
    }
    .habit-card.completed {
      opacity: 0.7;
      border-left: 4px solid #22c55e;
    }
    .habit-info { flex: 1; }
    .habit-top {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 4px;
    }
    .habit-title {
      margin: 0;
      font-size: 1.1rem;
      font-weight: 600;
    }
    .habit-meta {
      display: flex;
      gap: 16px;
      font-size: 0.85rem;
      opacity: 0.6;
    }
    .habit-actions {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .secondary-actions {
      display: flex;
    }
  `]
})
export class HabitCardComponent {
  habit = input.required<Habit>();

  onComplete = output<string>();
  onEdit = output<Habit>();
  onDelete = output<string>();

  isCompletedToday(): boolean {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return this.habit().completedDates.some(d => {
      const date = new Date(d);
      date.setHours(0, 0, 0, 0);
      return date.getTime() === today.getTime();
    });
  }
}

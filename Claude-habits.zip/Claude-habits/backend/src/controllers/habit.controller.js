const Habit = require('../models/habit.model');
const User = require('../models/user.model');
const { completeHabit } = require('../services/gamification.service');

async function list(req, res) {
  try {
    const habits = await Habit.find({ userId: req.userId }).sort({ createdAt: -1 });
    res.json(habits);
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
}

async function create(req, res) {
  try {
    const habit = await Habit.create({
      userId: req.userId,
      title: req.body.title.trim(),
      type: req.body.type,
    });
    res.status(201).json(habit);
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
}

async function update(req, res) {
  try {
    const habit = await Habit.findOne({ _id: req.params.id, userId: req.userId });
    if (!habit) return res.status(404).json({ error: 'Habitude non trouvee' });

    if (req.body.title) habit.title = req.body.title.trim();
    if (req.body.type) habit.type = req.body.type;
    await habit.save();

    res.json(habit);
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
}

async function remove(req, res) {
  try {
    const result = await Habit.deleteOne({ _id: req.params.id, userId: req.userId });
    if (result.deletedCount === 0) return res.status(404).json({ error: 'Habitude non trouvee' });
    res.json({ message: 'Habitude supprimee' });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
}

async function complete(req, res) {
  try {
    const habit = await Habit.findOne({ _id: req.params.id, userId: req.userId });
    if (!habit) return res.status(404).json({ error: 'Habitude non trouvee' });

    const user = await User.findById(req.userId);
    const result = await completeHabit(habit, user);

    if (result.error) {
      return res.status(400).json({ error: result.error });
    }

    res.json(result);
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
}

module.exports = { list, create, update, remove, complete };

const User = require('../models/user.model');
const Habit = require('../models/habit.model');
const { startOfDay } = require('../utils/date');

async function getMe(req, res) {
  try {
    const user = await User.findById(req.userId);
    if (!user) return res.status(404).json({ error: 'Utilisateur non trouve' });
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
}

async function getStats(req, res) {
  try {
    const user = await User.findById(req.userId);
    if (!user) return res.status(404).json({ error: 'Utilisateur non trouve' });

    const habits = await Habit.find({ userId: req.userId });

    const today = startOfDay();
    const completionsToday = habits.filter(h =>
      h.completedDates.some(d => startOfDay(d).getTime() === today.getTime())
    ).length;

    const bestStreak = habits.reduce((max, h) => Math.max(max, h.bestStreak), 0);
    const currentStreak = habits.reduce((max, h) => Math.max(max, h.streak), 0);

    res.json({
      xp: user.xp,
      level: user.level,
      xpForNextLevel: user.level * 100,
      xpProgress: user.xp % 100,
      totalHabits: habits.length,
      completionsToday,
      bestStreak,
      currentStreak,
    });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
}

module.exports = { getMe, getStats };

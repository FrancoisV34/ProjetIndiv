const { startOfDay, subDays, isSameDay } = require('../utils/date');

const XP_PER_COMPLETION = 10;

function calculateLevel(xp) {
  return Math.floor(xp / 100) + 1;
}

function isAlreadyCompletedToday(completedDates) {
  const today = startOfDay();
  return completedDates.some(d => isSameDay(d, today));
}

function calculateStreak(type, completedDates) {
  const today = startOfDay();

  if (type === 'daily') {
    const yesterday = startOfDay(subDays(today, 1));
    const hadYesterday = completedDates.some(d => isSameDay(d, yesterday));
    // Find current streak by looking backwards
    let streak = 1; // today counts
    if (hadYesterday) {
      // Count consecutive days backwards from yesterday
      let checkDate = yesterday;
      while (completedDates.some(d => isSameDay(d, checkDate))) {
        streak++;
        checkDate = startOfDay(subDays(checkDate, 1));
      }
    }
    return streak;
  }

  if (type === 'weekly') {
    // Check if there was a completion in the 7-14 days ago window
    const weekAgo = startOfDay(subDays(today, 7));
    const twoWeeksAgo = startOfDay(subDays(today, 14));
    const hadLastWeek = completedDates.some(d => {
      const t = startOfDay(d).getTime();
      return t >= twoWeeksAgo.getTime() && t < weekAgo.getTime();
    });

    if (hadLastWeek) {
      // Count consecutive weekly completions
      let streak = 1;
      let windowEnd = weekAgo;
      let windowStart = twoWeeksAgo;
      while (completedDates.some(d => {
        const t = startOfDay(d).getTime();
        return t >= windowStart.getTime() && t < windowEnd.getTime();
      })) {
        streak++;
        windowEnd = startOfDay(subDays(windowEnd, 7));
        windowStart = startOfDay(subDays(windowStart, 7));
      }
      return streak;
    }

    return 1;
  }

  return 1;
}

async function completeHabit(habit, user) {
  if (isAlreadyCompletedToday(habit.completedDates)) {
    return { error: 'Habitude deja completee aujourd\'hui' };
  }

  // Add today's completion
  habit.completedDates.push(new Date());

  // Calculate streak
  habit.streak = calculateStreak(habit.type, habit.completedDates);
  if (habit.streak > habit.bestStreak) {
    habit.bestStreak = habit.streak;
  }

  // Add XP and recalculate level
  const oldLevel = user.level;
  user.xp += XP_PER_COMPLETION;
  user.level = calculateLevel(user.xp);
  const leveledUp = user.level > oldLevel;

  await habit.save();
  await user.save();

  return {
    habit,
    user,
    xpGained: XP_PER_COMPLETION,
    leveledUp,
    newLevel: user.level,
  };
}

module.exports = { completeHabit, calculateLevel, XP_PER_COMPLETION };

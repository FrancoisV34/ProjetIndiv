function validateHabit(body) {
  const errors = [];
  if (!body.title || body.title.trim().length === 0) {
    errors.push('Le titre est requis');
  }
  if (body.title && body.title.length > 100) {
    errors.push('Le titre ne doit pas depasser 100 caracteres');
  }
  if (!['daily', 'weekly'].includes(body.type)) {
    errors.push('Le type doit etre "daily" ou "weekly"');
  }
  return errors;
}

module.exports = { validateHabit };

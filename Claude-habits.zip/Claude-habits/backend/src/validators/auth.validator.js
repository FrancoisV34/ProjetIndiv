function validateRegister(body) {
  const errors = [];
  if (!body.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email)) {
    errors.push('Email invalide');
  }
  if (!body.password || body.password.length < 6) {
    errors.push('Le mot de passe doit contenir au moins 6 caracteres');
  }
  return errors;
}

function validateLogin(body) {
  const errors = [];
  if (!body.email) errors.push('Email requis');
  if (!body.password) errors.push('Mot de passe requis');
  return errors;
}

module.exports = { validateRegister, validateLogin };

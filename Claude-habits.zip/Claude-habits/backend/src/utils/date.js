function startOfDay(date = new Date()) {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  return d;
}

function subDays(date, days) {
  const d = new Date(date);
  d.setDate(d.getDate() - days);
  return d;
}

function isSameDay(d1, d2) {
  return startOfDay(d1).getTime() === startOfDay(d2).getTime();
}

module.exports = { startOfDay, subDays, isSameDay };

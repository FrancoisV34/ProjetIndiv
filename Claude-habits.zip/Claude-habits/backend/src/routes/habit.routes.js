const { Router } = require('express');
const { list, create, update, remove, complete } = require('../controllers/habit.controller');
const authMiddleware = require('../middleware/auth.middleware');
const validate = require('../middleware/validate.middleware');
const { validateHabit } = require('../validators/habit.validator');

const router = Router();

router.use(authMiddleware);

router.get('/', list);
router.post('/', validate(validateHabit), create);
router.put('/:id', validate(validateHabit), update);
router.delete('/:id', remove);
router.post('/:id/complete', complete);

module.exports = router;

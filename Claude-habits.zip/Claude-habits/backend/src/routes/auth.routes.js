const { Router } = require('express');
const { register, login } = require('../controllers/auth.controller');
const validate = require('../middleware/validate.middleware');
const { validateRegister, validateLogin } = require('../validators/auth.validator');

const router = Router();

router.post('/register', validate(validateRegister), register);
router.post('/login', validate(validateLogin), login);

module.exports = router;

const { Router } = require('express');
const { getMe, getStats } = require('../controllers/user.controller');
const authMiddleware = require('../middleware/auth.middleware');

const router = Router();

router.use(authMiddleware);

router.get('/me', getMe);
router.get('/me/stats', getStats);

module.exports = router;
